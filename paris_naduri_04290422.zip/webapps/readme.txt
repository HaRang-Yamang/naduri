2021-04-23

sample.jsp : 본문 내용을 제외한 기본 틀 jsp입니다. 삭제하지 말아주세요!


메인 주소 : localhost:8088/naduri/index.jsp


공지사항 리스트 : localhost:8088/naduri/views/notice/noticeList.jsp
공지사항 내용 : localhost:8088/naduri/views/notice/noticeDetail.jsp
공지사항 쓰기 페이지 : localhost:8088/naduri/views/notice/noticeWrite.jsp


로그인 페이지 :localhost:8088/naduri/views/login.jsp
회원가입 페이지 : localhost:8088/naduri/views/member/joinMember.jsp
회원수정 페이지 : localhost:8088/naduri/views/member/modifyMember.jsp


비밀번호/아이디 찾기 페이지 : localhost:8088/naduri/views/find/findIdPwd.jsp
비밀번호 결과 : localhost:8088/naduri/views/find/findResultPwd.jsp
아이디 결과 : localhost:8088/naduri/views/find/findResultId.jsp


어드민 : localhost:8088/naduri/views/admin/adminData.jsp

	- 문화재 : localhost:8088/naduri/views/admin/adminHeritage.jsp
	- 맛집 : localhost:8088/naduri/views/admin/adminFood.jsp
	- 여행지 : localhost:8088/naduri/views/admin/adminSpot.jsp
	
	- 회원 관리 : localhost:8088/naduri/views/admin/adminMember.jsp


마이 페이지 : localhost:8088/naduri/views/myPage/myPage.jsp
	- 각 항목은 include 파일로 대체

상세 페이지 : http://localhost:8088/naduri/views/detail/detailHeritage.jsp
	- 상세 페이지 각 항목은 include 파일로 대체

리뷰 작성 페이지 : http://localhost:8088/naduri/views/reviewWrite.jsp
