package com.harang.naduri.jdbc.reply.model.service;

public class ReplyService {

}
