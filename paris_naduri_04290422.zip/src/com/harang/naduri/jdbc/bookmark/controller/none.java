package com.harang.naduri.jdbc.bookmark.controller;

public class none {
  // 폴더 없어지지 말라고 만든거에요 지우고 쓰세요
}
