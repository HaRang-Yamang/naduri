package com.harang.naduri.jdbc.review.model.dao;

public class ReviewDAO {

}
