package com.harang.naduri.jdbc.qna.model.service;

public class QnaService {

}
