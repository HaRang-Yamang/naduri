package com.harang.naduri.jdbc.review.model.service;

public class ReviewService {

}
