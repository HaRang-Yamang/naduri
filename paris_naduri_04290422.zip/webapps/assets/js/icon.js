/* markIcon */

const icon = document.querySelector('.markIcon');

icon.addEventListener('click', () => {
    icon.classList.toggle('active');
});
