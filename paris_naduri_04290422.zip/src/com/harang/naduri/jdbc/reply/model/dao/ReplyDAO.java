package com.harang.naduri.jdbc.reply.model.dao;

public class ReplyDAO {

}
