package com.harang.naduri.jdbc.qna.model.dao;

public class QnaDAO {

}
